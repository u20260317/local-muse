local-muse v1.1 · Windows 免安装包
==================================

【怎么运行】
双击 local-muse.exe 即可（不需要装 Python、不需要 pip）。
黑色控制台窗口不要关，关了服务就停。启动后浏览器打开：
  http://127.0.0.1:8765
第一次运行会在本目录下自动生成 db / logs / output / vault 等文件夹，属正常现象。
想先自检：在本目录打开终端，运行  local-muse.exe --setup-check

【zen-gate 的 key 怎么填】
本程序只连你本机的 zen-gate（127.0.0.1:8787），请先把 zen-gate 在本机跑起来。
双击启动时读不到环境变量，所以 key 请直接填进 config.json：
找到 "zen_gate_local" 那一段，把 "api_key": "" 改成你的 mainKey 保存即可。

【必须说清的一点：浏览器功能】
Browserr 官方目前只发布 Linux / macOS(arm64) / Android 引擎，没有 Windows 版，
所以在 Windows 上「浏览器采集」阶段用不了（setup-check 会如实报缺失），
其余功能（面板、调度、决策、文生图/视频、记忆、目标续行）都正常。
需要浏览器采集时，请在 Linux 或 Mac(Apple Silicon) 上跑源码版。

【目录说明】
local-muse.exe  启动器（双击它）
python\         内置 Python 3.12 运行环境（免安装，勿删）
main.py 等      程序本体 v1.1（与 GitHub 仓库 agent-loop-v1.1.0 同版）
